# Receipt Sender

## Setup
1. Clone repo  
2. `npm install`  
3. (Optional) Create `.env` for API keys  
4. `npm start`  
5. Open `http://localhost:3000/`

## Next
- Build /create-receipt form  
- Add PDF generation
- Add email sending
- Deploy to Render
