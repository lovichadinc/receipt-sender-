require('dotenv').config();
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => res.send('Receipt Sender is live!'));
app.get('/create-receipt', (req, res) =>
  res.send('<h1>Create Receipt Form Coming Soon</h1>')
);

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
